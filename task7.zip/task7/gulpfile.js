var gulp = require('gulp');
var concat = require('gulp-concat');

gulp.task('default', ['scripts', 'css']);

gulp.task('scripts', function() {
  	return gulp.src('./**/*.js')
    .pipe(concat('all.js'))
    .pipe(gulp.dest('./dist/'));
});

gulp.task('css', function() {
  	return gulp.src('./**/*.css')
    .pipe(concat('all.css'))
    .pipe(gulp.dest('./dist/'));
});